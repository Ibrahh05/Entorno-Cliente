let nombre="Ibrahim";
let apellido="Hanaoui";
let fechaNaciemiento=2005;
let edad=19;

alert('Estos son mis datos:');
alert("Nombre: " + nombre+"\n Apellido: " + apellido);
alert("Esta es la suma de mi año de nacimiento y mi edad: " + (fechaNaciemiento + edad));
alert("Esta es la suma de mis variables: "+ (nombre + apellido + fechaNaciemiento + edad));
