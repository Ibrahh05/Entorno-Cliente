let entero=1357;
let decimal=1357;
let cientifico=135e7;
let octal= 0o1357;
let hexadecimal= 0x1357;

alert("Número entero: " + entero);
alert("Número decimal: " + decimal);
alert("Número en notación científica: " + cientifico);
alert("Número en notación octal: " + octal);
alert("Número en notación hexadecimal: " + hexadecimal);