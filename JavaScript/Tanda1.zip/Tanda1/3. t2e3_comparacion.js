let operacion1 = (10 == 10);
alert ("La operación 10==10 es: "+operacion1);
let operacion2 = (10 === 10);
alert ("La operación 10===10 es: "+operacion2);
let operacion3 = (10 === 10.0);
alert ("La operación 10===10 es: "+operacion3);
let operacion4 = ("Laura" == "laura");
alert ("La operación 'Laura' == 'laura' es: "+operacion4);
let operacion5 = ("Laura" > "laura");
alert ("La operación 'Laura' > 'laura' es: "+operacion5);
let operacion6 = ("Laura" < "laura");
alert ("La operación 'Laura' < 'laura' es: "+operacion6);
let operacion7 = ("123" == 123);
alert ("La operación '123' == 123 es: "+operacion7);
let operacion8 = ("123" === 123);
alert ("La operación '123' === 123 es: "+operacion8);
let operacion9 = (parseInt("123") === 123);
alert ("La operación parseInt('123') === 123 es: "+operacion9);

